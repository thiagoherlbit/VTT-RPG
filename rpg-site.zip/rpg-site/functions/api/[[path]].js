// API da mesa de RPG (Cloudflare Pages Function). Precisa do KV "RPG" e da variável MASTER_KEY.
const J=(d,s=200)=>new Response(JSON.stringify(d),{status:s,headers:{'content-type':'application/json'}});
export async function onRequest({request,env,params}){
  if(!env.RPG||!env.MASTER_KEY)return J({error:'Faltou configurar o KV "RPG" e a variável MASTER_KEY no Cloudflare.'},500);
  const key=request.headers.get('x-key')||'',[a,b]=[].concat(params.path||[]),m=request.method;
  const players=JSON.parse(await env.RPG.get('players')||'[]');
  const master=key===env.MASTER_KEY,pl=!master&&key&&players.find(p=>p.pin===key);
  if(!master&&!pl)return J({error:'Código inválido'},401);
  const body=['POST','PUT','PATCH'].includes(m)?await request.json().catch(()=>({})):{};
  if(a==='me')return J({role:master?'master':'player',id:pl?pl.id:undefined});
  if(a==='sheets'){
    const out=[];
    for(const p of players){
      if(!master&&p.id!==pl.id)continue;
      const s=JSON.parse(await env.RPG.get('sheet:'+p.id)||'null');
      if(s&&!master)delete s.mnotes; // anotações secretas do mestre
      out.push({id:p.id,name:p.name,pin:master?p.pin:undefined,sheet:s});
    }
    return J({players:out});
  }
  if(a==='sheet'&&m==='PUT'){
    if(!master&&b!==pl.id)return J({error:'Sem permissão'},403);
    if(!players.some(p=>p.id===b))return J({error:'Jogador não existe'},404);
    const old=JSON.parse(await env.RPG.get('sheet:'+b)||'null')||{},s=body;
    if(!master){ // jogador não mexe em campos do mestre
      s.lock=!!old.lock;s.mnotes=old.mnotes||'';
      if(old.lock&&old.attrs)s.attrs=old.attrs;
    }
    const txt=JSON.stringify(s);
    if(txt.length>300000)return J({error:'Ficha grande demais'},413);
    await env.RPG.put('sheet:'+b,txt);
    return J({ok:1});
  }
  if(a==='players'){
    if(!master)return J({error:'Só o mestre pode isso'},403);
    const bad=pin=>!pin||pin===env.MASTER_KEY||players.some(p=>p.pin===pin&&p.id!==b);
    if(m==='POST'){
      if(!body.name||bad(body.pin))return J({error:'Informe um nome e um código que ninguém use'},400);
      players.push({id:crypto.randomUUID().slice(0,8),name:body.name,pin:body.pin});
    }else if(m==='PATCH'){
      const p=players.find(p=>p.id===b);
      if(!p)return J({error:'Jogador não existe'},404);
      if(body.pin&&bad(body.pin))return J({error:'Esse código já está em uso'},400);
      p.name=body.name||p.name;p.pin=body.pin||p.pin;
    }else if(m==='DELETE'){
      const i=players.findIndex(p=>p.id===b);
      if(i>=0){players.splice(i,1);await env.RPG.delete('sheet:'+b)}
    }
    await env.RPG.put('players',JSON.stringify(players));
    return J({ok:1});
  }
  return J({error:'Rota não existe'},404);
}
