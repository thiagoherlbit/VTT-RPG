# Mesa de RPG (Cloudflare Pages)
Estrutura: `public/` (site) + `functions/api/[[path]].js` (API).
Deploy: suba esta pasta num repositório GitHub e conecte no Pages (Build command: vazio · Output directory: `public`).
Depois, em Settings do projeto no Pages:
1. Bindings → KV namespace → variável `RPG` (crie um namespace em Workers & Pages → KV).
2. Variables and Secrets → `MASTER_KEY` (a senha do mestre).
3. Faça um novo deploy.
